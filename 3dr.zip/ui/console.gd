extends CanvasLayer

@onready var lines: RichTextLabel
@onready var input: LineEdit

var history: Array[String]
var h_index := -1
var load_status: int = 0
var load_call: Callable

#region auto setup options
## Enables auto setup options
static var AUTO_SETUP: bool = false
## Game will fullscreen
static var AUTO_FULLSCREEN: bool = true
## Local instances will connect to eachother
static var AUTO_JOIN: bool = true
## Starts the game after clients are connected
static var AUTO_START_GAME: bool = true
## Clients wont move or take damage to sudden death
static var CLIENT_DUMMY: bool = false
#endregion

#region debugging options
static var DEBUG: bool = false
static var MAX_CARD_OPTIONS: int = 15
static var AUTO_INIT_CARD_SELECT: bool = true
static var AUTO_CARD_SELECT: bool = false
static var AUTO_LEVEL_LOAD: bool = false
#endregion


func _ready() -> void:
	lines = $margin/vbox/lines as RichTextLabel
	input = $margin/vbox/input as LineEdit
	history = []
	input.text_submitted.connect(submit_console)
	
	AUTO_FULLSCREEN = AUTO_FULLSCREEN && AUTO_SETUP
	AUTO_JOIN = AUTO_JOIN && AUTO_SETUP
	AUTO_START_GAME = AUTO_START_GAME && AUTO_SETUP
	CLIENT_DUMMY = CLIENT_DUMMY && AUTO_SETUP
	
	AUTO_INIT_CARD_SELECT = AUTO_INIT_CARD_SELECT && DEBUG
	AUTO_CARD_SELECT = AUTO_CARD_SELECT && DEBUG
	AUTO_LEVEL_LOAD = AUTO_LEVEL_LOAD && DEBUG


func _process(_delta: float) -> void:
	if load_status % 3 == 1:
		load_call.call_deferred()
		load_status += 1
	if load_status % 3 == 2: return
	match load_status:
		0: attempt_load(load_cards, &"Loading Cards")
		3: attempt_load(load_resources, &"Loading Resources")
		#0: attempt_load(Global.load_resources, "Loading Global Resources")
		#3: attempt_load(Server.load_resources, "Loading Server Resources")
		#6: attempt_load(ProcItem.register_all, "Loading Static Items")
		#9: attempt_load(self.cleanup, "Cleaning up")
		#12: attempt_load(func():Limbo.goto.call_deferred(Limbo.MAIN_MENU), "Starting Main Menu...")

func attempt_load(load_step: Callable, load_name: String) -> void:
	self.print(load_name)
	load_call = load_step
	load_status += 1

func load_cards() -> void:
	load_status += 1
	Card.register_all_decks()
	Card.register_all_cards()
	Console.print(&"Total cards: %s" % Card.ALL_CARDS.size())

func load_resources() -> void:
	load_status += 1 +3+3+3
	# TODO make more preloads into load
	Util.PLAYER_ICON_SCN = load("res://ui/player_icon.tscn") as PackedScene
	VFXHandler.load_all_effects()
	SFXHandler.load_all_sounds()
	AltProjHandler.load_all_projs()
	FieldHandler.load_all_fields()
	
	self.print(&"CLoad complete, initalizing")
	await get_tree().create_timer(0.2).timeout
	get_tree().change_scene_to_file(&"res://ui/connection_ui.tscn")
	load_status = -1
	toggle_console()

####################################################################################################################################################################################
## # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
####################################################################################################################################################################################

func _input(event: InputEvent) -> void:
	if event is InputEventKey && event.is_pressed():
		if event.is_action(&"dbg_console") || (event.is_action(&"escape") && visible): call_deferred(&"toggle_console")
		if event.keycode == KEY_UP:
			h_index = clamp(h_index +1, -1, history.size() -1)
			input.clear()
			if h_index != -1: input.insert_text_at_caret(history[h_index])
		if event.keycode == KEY_DOWN:
			h_index = clamp(h_index -1, -1, history.size() -1)
			input.clear()
			if h_index != -1: input.insert_text_at_caret(history[h_index])

func toggle_console() -> void:
	if load_status > -1: return
	visible = !visible
	set_process(visible)
	if visible:
		input.grab_focus()
		input.text = ""

func submit_console(text: String) -> void:
	input.text = ""
	parse_command(text)
	h_index = -1
	if (history.size() > 0 && history[0] != text) || history.size() == 0: history.push_front(text)

func print(text: String) -> void:
	print_rich(&"[Console] " + text.replace(&"\n", &"\n          "))
	lines.text += (&"\n" if !lines.text.is_empty() else &"") + text

func print_err(text: String) -> void:
	print_rich(&"[color=red][Error] " + text.replace(&"\n", &"\n[Error] ") + &"[/color]")
	push_error(&"[Error] " + text.replace(&"\n", &"\n[Error] "))
	lines.text += (&"\n" if !lines.text.is_empty() else &"") + &"[color=red]" + text + &"[/color]"

func parse_command(text: String) -> void:
	var commands := Util.split_in_same_level(text, &";")
	self.print(&"> " + text)
	for command in commands:
		var args := Util.split_in_same_level(command, &" ")
		#while args.size() > 0 && !args[0].is_empty(): args.pop_front() #TODO ???
		run_command(args)

var hit_error: bool = false
var is_help: bool = false
func help(txt: StringName) -> bool:
	if is_help: self.print(txt)
	return is_help
func run_command(args: Array[String]) -> void:
	hit_error = false
	if args.size() == 0: return
	match args[0]:
		&"help":
			if help(&"help [command]"):return
			match args.size():
				1: self.print(&"Commands: help fps net dash card fullscreen")
				2:
					is_help = true
					args.pop_front()
					run_command(args)
					is_help = false
				3: exact_args(args, 2)
		&"fps":
			if help(&"fps [target:int]"): return
			if args.size() < 2: return self.print(&"FPS target: %s (%s mspt), Running: %s" % [&"uncapped" if Engine.max_fps == 0 else StringName(str(Engine.max_fps)),round(1000.0/Engine.max_fps),Engine.get_frames_per_second()])
			Engine.max_fps = int(args[1])
			self.print(&"FPS target set to %s (%s mspt)" % [Engine.max_fps,round(1000.0/Engine.max_fps)])
		&"net":
			if help(&"net <info|state> [value]"): return
			if !(exact_args(args, 1) || exact_args(args, 2)): return
			match args[1]:
				&"info":
					self.print(&"Network[%s]: S:%s N:%s" % [Network.uuid, Network.NS_NAME[Network.self_player.state], Network.NS_NAME[Network.next_state]])
				&"state":
					Network.change_to_state(Network.NS_NAME.find(args[2]))
		&"dash":
			if help(&"dash <type:int[0,4]>"): return
			if !exact_args(args, 1): return
			Game.player.dash_type = int(args[1])
			self.print(&"Dash type set to %s" % args[1])
		&"card":
			if help(&"card <list> | card <give> <id> [count:int]"): return
			if !min_args(args, 1): return
			match args[1]:
				&"list":
					self.print(&"All Cards:\n%s" % Util.format_array(Card.ALL_CARDS.map(func(c:Card)->String:return c.uuid)))
				&"give":
					var target := args[2].trim_prefix(&'"').trim_suffix(&'"')
					var idx := Card.ALL_CARDS.find_custom(func(c:Card)->bool: return c.uuid==target)
					if idx != -1:
						var count := 1
						if args.size() == 4: count = int(args[3])
						Game.player.add_card(Card.ALL_CARDS[idx], count)
						Game.player.update_cards()
						self.print(&"Give card %s x %s" % [args[2], count])
					else:
						print_err(&"Card not found: %s" % args[2])
		&"fullscreen":
			if help(&"fullscreen"): return
			if !exact_args(args, 0): return
			DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_FULLSCREEN)
		_ when !hit_error: print_err(&"Unknown Command '%s'" % args[0])
		_: pass

func exact_args(args: Array[String], count: int) -> bool:
	if args.size() == count+1: return true
	hit_error = true
	print_err(&"Invalid arguments, expected %s got %s" % [count, args.size()-1])
	return false

func min_args(args: Array[String], count: int) -> bool:
	if args.size() >= count+1: return true
	hit_error = true
	print_err(&"Invalid arguments, expected %s got %s" % [count, args.size()-1])
	return false

func in_game() -> bool:
	if Game: return true
	hit_error = true
	print_err(&"Must be in-game to use this command")
	return false
